from flask import Flask, jsonify, request, json
import sqlite3

app = Flask(__name__)
DATABASE = 'data.json'


def get_db():
    conn = sqlite3.connect(DATABASE)
    return conn


@app.route('/tickets', methods=['GET'])
def get_tickets():
    with open('data.json', 'r') as json_file:
        tickets_data = json.load(json_file)

    return jsonify(tickets_data)


@app.route('/tickets', methods=['GET'])
def get_all_tickets():
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM tickets')
    tickets = cursor.fetchall()
    conn.close()

    # Format the ticket data as a list of dictionaries
    tickets_list = []
    for ticket in tickets:
        ticket_dict = {
            'id': ticket[0],
            'title': ticket[1],
            'content': ticket[2],
            'userEmail': ticket[3],
            'creationTime': ticket[4]
        }
        tickets_list.append(ticket_dict)

    return jsonify(tickets_list)


@app.route('/tickets/search', methods=['GET'])
def search_tickets_by_title():
    search_query = request.args.get('q')
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute('SELECT * FROM tickets WHERE title LIKE ?', ('%' + search_query + '%',))
    tickets = cursor.fetchall()
    conn.close()

    # Format the ticket data as a list of dictionaries
    tickets_list = []
    for ticket in tickets:
        ticket_dict = {
            'id': ticket[0],
            'title': ticket[1],
            'description': ticket[2],
            'status': ticket[3]
        }
        tickets_list.append(ticket_dict)

    return jsonify(tickets_list)


@app.route('/tickets/search', methods=['GET'])
def search_tickets_by_time():
    search_query = request.args.get('q')
    from_time = request.args.get('from')
    to_time = request.args.get('to')

    query = 'SELECT * FROM tickets WHERE title LIKE ?'
    params = ['%' + search_query + '%']

    if from_time and to_time:
        query += ' AND created_at BETWEEN ? AND ?'
        params.extend([from_time, to_time])
    elif from_time:
        query += ' AND created_at >= ?'
        params.append(from_time)
    elif to_time:
        query += ' AND created_at <= ?'
        params.append(to_time)

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(query, params)
    tickets = cursor.fetchall()
    conn.close()

    # Format the ticket data as a list of dictionaries
    tickets_list = []
    for ticket in tickets:
        ticket_dict = {
            'id': ticket[0],
            'title': ticket[1],
            'description': ticket[2],
            'status': ticket[3]
        }
        tickets_list.append(ticket_dict)

    return jsonify(tickets_list)


@app.route('/tickets/search', methods=['GET'])
def search_tickets_by_all():
    search_query = request.args.get('q')
    from_time = request.args.get('from')
    to_time = request.args.get('to')

    query = 'SELECT * FROM tickets WHERE title LIKE ? OR content LIKE ? OR email LIKE ?'
    params = ['%' + search_query + '%', '%' + search_query + '%', '%' + search_query + '%']

    if from_time and to_time:
        query += ' AND created_at BETWEEN ? AND ?'
        params.extend([from_time, to_time])
    elif from_time:
        query += ' AND created_at >= ?'
        params.append(from_time)
    elif to_time:
        query += ' AND created_at <= ?'
        params.append(to_time)

    conn = get_db()
    cursor = conn.cursor()
    cursor.execute(query, params)
    tickets = cursor.fetchall()
    conn.close()

    # Format the ticket data as a list of dictionaries
    tickets_list = []
    for ticket in tickets:
        ticket_dict = {
            'id': ticket[0],
            'title': ticket[1],
            'description': ticket[2],
            'status': ticket[3]
        }
        tickets_list.append(ticket_dict)

    return jsonify(tickets_list)


if __name__ == '__main__':
    app.run()
